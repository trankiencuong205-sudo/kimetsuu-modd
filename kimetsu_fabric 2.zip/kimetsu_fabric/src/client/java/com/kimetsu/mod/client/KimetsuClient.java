package com.kimetsu.mod.client;

import com.kimetsu.mod.KimetsuMod;
import net.fabricmc.api.ClientModInitializer;

/**
 * Điểm vào phía client: keybind, GUI menu kỹ năng, HUD năng lượng/hồi chiêu,
 * renderer hiệu ứng. Chỉ chạy trên client.
 */
public class KimetsuClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KimetsuMod.LOGGER.info("Kimetsu mod da khoi dong (client)");
    }
}
