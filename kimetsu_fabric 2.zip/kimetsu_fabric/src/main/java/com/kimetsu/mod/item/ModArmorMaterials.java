package com.kimetsu.mod.item;

import com.kimetsu.mod.KimetsuMod;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

/**
 * Chất liệu giáp cho đồng phục Sát Quỷ Đoàn.
 * Cú pháp lấy từ docs Fabric 1.21.11 (custom armor). Các đường dẫn import
 * (package) chưa được biên dịch thử.
 */
public final class ModArmorMaterials {
    public static final int BASE_DURABILITY = 25;

    /** Khớp với file assets/kimetsu/equipment/kimetsu_uniform.json */
    public static final ResourceKey<EquipmentAsset> UNIFORM_KEY = ResourceKey.create(
            EquipmentAssets.ROOT_ID,
            Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "kimetsu_uniform"));

    /** Tag sửa chữa: data/kimetsu/tags/item/repairs_uniform.json */
    public static final TagKey<Item> REPAIRS_UNIFORM = TagKey.create(
            BuiltInRegistries.ITEM.key(),
            Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "repairs_uniform"));

    // Tham số theo thứ tự: độ bền gốc, giáp từng phần, độ phù phép, âm thanh mặc,
    // độ cứng (toughness), kháng đẩy lùi, tag sửa chữa, khóa equipment asset.
    public static final ArmorMaterial UNIFORM = new ArmorMaterial(
            BASE_DURABILITY,
            Map.of(
                    ArmorType.BOOTS, 2,
                    ArmorType.LEGGINGS, 4,
                    ArmorType.CHESTPLATE, 5,
                    ArmorType.HELMET, 2
            ),
            15,
            SoundEvents.ARMOR_EQUIP_LEATHER,
            0.0F,
            0.0F,
            REPAIRS_UNIFORM,
            UNIFORM_KEY
    );

    private ModArmorMaterials() {
    }
}
