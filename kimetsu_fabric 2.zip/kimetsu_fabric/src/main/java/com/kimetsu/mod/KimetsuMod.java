package com.kimetsu.mod;

import com.kimetsu.mod.item.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Điểm vào chung (server + client). Các hệ thống được đăng ký từ đây,
 * mỗi hệ thống nằm trong package riêng (item, breathing, demon, network, ...).
 */
public class KimetsuMod implements ModInitializer {
    public static final String MOD_ID = "kimetsu";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.initialize();
        LOGGER.info("Kimetsu mod da khoi dong (common)");
    }
}
