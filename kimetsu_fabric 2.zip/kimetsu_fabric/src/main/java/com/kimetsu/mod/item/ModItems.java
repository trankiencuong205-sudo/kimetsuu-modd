package com.kimetsu.mod.item;

import com.kimetsu.mod.KimetsuMod;
import java.util.function.Function;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorType;

/**
 * Đăng ký toàn bộ item của mod. Cú pháp đăng ký lấy từ docs Fabric 1.21.11
 * (first-item, custom-tools, custom-armor). Import package chưa được biên dịch thử.
 */
public final class ModItems {

    public static <T extends Item> T register(String name, Function<Item.Properties, T> itemFactory,
                                              Item.Properties properties) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
                Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, name));
        T item = itemFactory.apply(properties.setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        return item;
    }

    /** Kiếm Nichirin: sát thương gốc 3.0 (cộng với 3.0 của vật liệu), tốc độ -2.2. */
    public static final Item NICHIRIN_SWORD = register("nichirin_sword", Item::new,
            new Item.Properties().sword(ModToolMaterials.NICHIRIN, 3.0F, -2.2F));

    /** Máu quỷ: logic uống để hóa quỷ sẽ thêm ở giai đoạn hệ thống quỷ. */
    public static final Item DEMON_BLOOD = register("demon_blood", Item::new,
            new Item.Properties().stacksTo(16));

    public static final Item UNIFORM_JACKET = register("kimetsu_uniform_jacket", Item::new,
            new Item.Properties()
                    .humanoidArmor(ModArmorMaterials.UNIFORM, ArmorType.CHESTPLATE)
                    .durability(ArmorType.CHESTPLATE.getDurability(ModArmorMaterials.BASE_DURABILITY)));

    public static final Item UNIFORM_LEGGINGS = register("kimetsu_uniform_leggings", Item::new,
            new Item.Properties()
                    .humanoidArmor(ModArmorMaterials.UNIFORM, ArmorType.LEGGINGS)
                    .durability(ArmorType.LEGGINGS.getDurability(ModArmorMaterials.BASE_DURABILITY)));

    public static final Item UNIFORM_BOOTS = register("kimetsu_uniform_boots", Item::new,
            new Item.Properties()
                    .humanoidArmor(ModArmorMaterials.UNIFORM, ArmorType.BOOTS)
                    .durability(ArmorType.BOOTS.getDurability(ModArmorMaterials.BASE_DURABILITY)));

    public static void initialize() {
        // Tạm thời đặt vào các tab có sẵn; tab sáng tạo riêng của mod sẽ thêm sau.
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(group -> {
            group.accept(NICHIRIN_SWORD);
            group.accept(UNIFORM_JACKET);
            group.accept(UNIFORM_LEGGINGS);
            group.accept(UNIFORM_BOOTS);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS)
                .register(group -> group.accept(DEMON_BLOOD));
    }

    private ModItems() {
    }
}
