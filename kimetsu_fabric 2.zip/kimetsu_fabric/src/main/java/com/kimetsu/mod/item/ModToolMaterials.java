package com.kimetsu.mod.item;

import com.kimetsu.mod.KimetsuMod;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;

/**
 * Vật liệu công cụ cho kiếm Nichirin.
 * Cú pháp lấy từ docs Fabric 1.21.11 (custom tools). Các đường dẫn import
 * (package) chưa được biên dịch thử; nếu CI báo sai package, sửa theo IDE.
 */
public final class ModToolMaterials {
    /** Tag vật phẩm dùng để sửa kiếm: data/kimetsu/tags/item/repairs_nichirin.json */
    public static final TagKey<Item> REPAIRS_NICHIRIN = TagKey.create(
            BuiltInRegistries.ITEM.key(),
            Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "repairs_nichirin"));

    // Tham số theo thứ tự: tag block không rơi đồ, độ bền, tốc độ đào,
    // sát thương cộng thêm, độ phù phép, tag sửa chữa.
    public static final ToolMaterial NICHIRIN = new ToolMaterial(
            BlockTags.INCORRECT_FOR_IRON_TOOL,
            1561,
            6.0F,
            3.0F,
            18,
            REPAIRS_NICHIRIN
    );

    private ModToolMaterials() {
    }
}
