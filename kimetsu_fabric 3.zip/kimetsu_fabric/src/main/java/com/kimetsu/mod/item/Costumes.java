package com.kimetsu.mod.item;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

/**
 * Trang phục thẩm mỹ (không cộng giáp): 4 haori, 3 mặt nạ, 2 hakama, 1 dép.
 * Đều là thiết kế gốc của mod, mặc được vào đúng ô giáp và lưu cùng đồ người chơi.
 * Danh sách ALL dùng cho menu chọn trang phục.
 */
public final class Costumes {
    public record Costume(String id, EquipmentSlot slot, Item item) {
    }

    public static final List<Costume> ALL = new ArrayList<>();

    private static Item add(String id, ArmorType type, EquipmentSlot slot) {
        ArmorMaterial material = ModArmorMaterials.cosmetic(id);
        Item item = ModItems.register(id, Item::new, new Item.Properties()
                .humanoidArmor(material, type)
                .durability(type.getDurability(ModArmorMaterials.COSMETIC_DURABILITY)));
        ALL.add(new Costume(id, slot, item));
        return item;
    }

    // Haori (áo khoác ngoài)
    public static final Item HAORI_WAVE = add("haori_wave", ArmorType.CHESTPLATE, EquipmentSlot.CHEST);
    public static final Item HAORI_DUSK = add("haori_dusk", ArmorType.CHESTPLATE, EquipmentSlot.CHEST);
    public static final Item HAORI_STARRY = add("haori_starry", ArmorType.CHESTPLATE, EquipmentSlot.CHEST);
    public static final Item HAORI_MAPLE = add("haori_maple", ArmorType.CHESTPLATE, EquipmentSlot.CHEST);

    // Mặt nạ
    public static final Item MASK_FOX = add("mask_fox", ArmorType.HELMET, EquipmentSlot.HEAD);
    public static final Item MASK_ONI = add("mask_oni", ArmorType.HELMET, EquipmentSlot.HEAD);
    public static final Item MASK_BANDAGE = add("mask_bandage", ArmorType.HELMET, EquipmentSlot.HEAD);

    // Hakama (quần) và dép
    public static final Item HAKAMA_DARK = add("hakama_dark", ArmorType.LEGGINGS, EquipmentSlot.LEGS);
    public static final Item HAKAMA_WHITE = add("hakama_white", ArmorType.LEGGINGS, EquipmentSlot.LEGS);
    public static final Item ZORI_SANDALS = add("zori_sandals", ArmorType.BOOTS, EquipmentSlot.FEET);

    public static Costume find(String id) {
        for (Costume c : ALL) {
            if (c.id().equals(id)) {
                return c;
            }
        }
        return null;
    }

    /** Gọi sớm để các item được đăng ký trước khi registry bị khóa. */
    public static void init() {
    }

    private Costumes() {
    }
}
