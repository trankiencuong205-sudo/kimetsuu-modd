package com.kimetsu.mod.skill;

/** Kiểu hình học/hoạt ảnh của kỹ năng. Mỗi kiểu có cách vẽ hiệu ứng và tính trúng riêng. */
public enum SkillShape {
    /** Một nhát chém cung trước mặt, vẽ quét theo từng tick. */
    SLASH,
    /** Hai nhát chém chéo nối tiếp nhau. */
    CROSS,
    /** Vòng xoáy quanh người, quét hết các mục tiêu xung quanh. */
    SPIN,
    /** Lao nhanh về phía trước, gây sát thương suốt đường đi. */
    DASH,
    /** Bật lên rồi đáp xuống, nổ vòng sóng xung kích. */
    LEAP,
    /** Làn sóng hình lưỡi liềm bay thẳng về phía trước. */
    WAVE,
    /** Dãy cột nổ trồi lên dọc theo hướng nhìn. */
    PILLARS,
    /** Mưa rơi xuống vùng phía trước, sát thương theo nhịp. */
    RAIN,
    /** Những con rắn uốn lượn tự đuổi mục tiêu. */
    SERPENT,
    /** Hào quang quanh người: buff bản thân hoặc làm yếu kẻ địch xung quanh. */
    AURA
}
