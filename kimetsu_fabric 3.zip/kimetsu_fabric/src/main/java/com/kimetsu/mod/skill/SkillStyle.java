package com.kimetsu.mod.skill;

import java.util.List;

/**
 * Một Hơi Thở (art=false) hoặc một trường phái Huyết Quỷ Thuật (art=true),
 * gồm danh sách các kỹ năng theo thứ tự phím 1..N.
 */
public record SkillStyle(String id, boolean art, int color, List<SkillDef> skills) {

    public String nameKey() {
        return "style.kimetsu." + id;
    }
}
