package com.kimetsu.mod.skill;

/** Hiệu ứng phụ của một kỹ năng lên mục tiêu (hoặc lên bản thân với GUARD/HEAL). */
public enum Extra {
    NONE,
    IGNITE,
    SLOW,
    BLIND,
    WEAKEN,
    POISON,
    FREEZE,
    LIFT,
    GUARD,
    HEAL
}
