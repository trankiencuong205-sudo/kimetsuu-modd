package com.kimetsu.mod.skill;

import net.minecraft.core.particles.ParticleOptions;

/**
 * Định nghĩa dữ liệu của một kỹ năng (một thức Hơi Thở hoặc một Huyết Quỷ Thuật).
 *
 * @param damage     sát thương gốc (được nhân theo cấp độ người chơi)
 * @param range      tầm/bán kính tính bằng block
 * @param cost       năng lượng tiêu hao
 * @param cooldown   thời gian hồi chiêu, tính bằng tick (20 tick = 1 giây)
 * @param minLevel   cấp độ tối thiểu để mở khóa
 * @param color      màu chính (RGB) của hiệu ứng
 * @param color2     màu phụ (RGB)
 * @param accent     loại hạt vanilla đặc trưng của nguyên tố
 * @param sound      id âm thanh vanilla, ví dụ "entity.player.attack.sweep"
 * @param extra      hiệu ứng phụ lên mục tiêu
 * @param extraTicks thời lượng hiệu ứng phụ (tick)
 * @param dash       tốc độ lao (cho DASH)
 * @param count      số con rắn (cho SERPENT; số âm = xếp thành vòng tròn)
 */
public record SkillDef(String id, SkillShape shape, float damage, float range, float cost,
                       int cooldown, int minLevel, int color, int color2,
                       ParticleOptions accent, String sound, Extra extra,
                       int extraTicks, double dash, int count) {

    public String nameKey() {
        return "skill.kimetsu." + id;
    }
}
