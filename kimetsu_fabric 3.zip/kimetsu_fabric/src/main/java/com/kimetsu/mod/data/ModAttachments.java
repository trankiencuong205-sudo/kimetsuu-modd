package com.kimetsu.mod.data;

import com.kimetsu.mod.KimetsuMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;

/**
 * Đăng ký dữ liệu người chơi bằng Fabric Data Attachment API:
 *  - persistent: lưu vào file người chơi, còn nguyên sau khi thoát game và vào lại
 *  - copyOnDeath: giữ trạng thái quỷ/kinh nghiệm sau khi chết
 *  - syncWith(targetOnly): máy chủ tự gửi cho chính người chơi đó để HUD hiển thị
 */
public final class ModAttachments {
    public static final AttachmentType<PlayerState> STATE = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "player_state"),
            builder -> builder
                    .initializer(() -> PlayerState.DEFAULT)
                    .persistent(PlayerState.CODEC)
                    .copyOnDeath()
                    .syncWith(ByteBufCodecs.fromCodec(PlayerState.CODEC), AttachmentSyncPredicate.targetOnly())
    );

    /** Gọi để chắc chắn lớp này được nạp (và attachment được đăng ký) lúc khởi động. */
    public static void init() {
    }

    private ModAttachments() {
    }
}
