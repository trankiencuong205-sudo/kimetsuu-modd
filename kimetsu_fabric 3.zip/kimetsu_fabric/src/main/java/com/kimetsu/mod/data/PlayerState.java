package com.kimetsu.mod.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.HashMap;
import java.util.Map;

/**
 * Trạng thái của một người chơi: quỷ hay người, Hơi Thở đang chọn, trường phái
 * Huyết Quỷ Thuật, kinh nghiệm, năng lượng và thời gian hồi chiêu.
 *
 * Bất biến (record) vì Fabric Data Attachment yêu cầu: mọi thay đổi đều tạo
 * bản mới rồi setAttached. Năng lượng hồi lại theo thời gian được tính lười
 * (lazy) từ energyTick nên không cần gửi gói tin mỗi tick.
 */
public record PlayerState(boolean demon, String style, String school, int xp,
                          float energy, long energyTick,
                          Map<String, Long> cooldowns, String costume) {

    public static final int MAX_LEVEL = 20;
    public static final int XP_PER_LEVEL = 120;

    public static final PlayerState DEFAULT =
            new PlayerState(false, "water", "", 0, 100f, 0L, Map.of(), "");

    public static final Codec<PlayerState> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.BOOL.optionalFieldOf("demon", false).forGetter(PlayerState::demon),
            Codec.STRING.optionalFieldOf("style", "water").forGetter(PlayerState::style),
            Codec.STRING.optionalFieldOf("school", "").forGetter(PlayerState::school),
            Codec.INT.optionalFieldOf("xp", 0).forGetter(PlayerState::xp),
            Codec.FLOAT.optionalFieldOf("energy", 100f).forGetter(PlayerState::energy),
            Codec.LONG.optionalFieldOf("energy_tick", 0L).forGetter(PlayerState::energyTick),
            Codec.unboundedMap(Codec.STRING, Codec.LONG)
                    .optionalFieldOf("cooldowns", Map.of()).forGetter(PlayerState::cooldowns),
            Codec.STRING.optionalFieldOf("costume", "").forGetter(PlayerState::costume)
    ).apply(i, PlayerState::new));

    public int level() {
        return Math.min(MAX_LEVEL, 1 + xp / XP_PER_LEVEL);
    }

    public float maxEnergy() {
        return 100f + 6f * (level() - 1);
    }

    /** Năng lượng hồi mỗi tick. Quỷ hồi nhanh hơn. */
    public float regenPerTick() {
        return demon ? 0.5f : 0.3f;
    }

    public float energyAt(long now) {
        long dt = Math.max(0L, now - energyTick);
        return Math.min(maxEnergy(), energy + dt * regenPerTick());
    }

    public boolean ready(String skillId, long now) {
        return cooldowns.getOrDefault(skillId, 0L) <= now;
    }

    public long readyAt(String skillId) {
        return cooldowns.getOrDefault(skillId, 0L);
    }

    public PlayerState spend(float cost, long now) {
        return new PlayerState(demon, style, school, xp, energyAt(now) - cost, now, cooldowns, costume);
    }

    public PlayerState withEnergy(float value, long now) {
        return new PlayerState(demon, style, school, xp, value, now, cooldowns, costume);
    }

    public PlayerState withCooldown(String skillId, long readyAt, long now) {
        Map<String, Long> m = new HashMap<>();
        for (Map.Entry<String, Long> e : cooldowns.entrySet()) {
            if (e.getValue() > now) {
                m.put(e.getKey(), e.getValue());
            }
        }
        m.put(skillId, readyAt);
        return new PlayerState(demon, style, school, xp, energy, energyTick, Map.copyOf(m), costume);
    }

    public PlayerState withXp(int value) {
        return new PlayerState(demon, style, school, value, energy, energyTick, cooldowns, costume);
    }

    public PlayerState withStyle(String value) {
        return new PlayerState(demon, value, school, xp, energy, energyTick, cooldowns, costume);
    }

    public PlayerState withDemon(boolean isDemon, String newSchool) {
        return new PlayerState(isDemon, style, newSchool, xp, energy, energyTick, Map.of(), costume);
    }

    public PlayerState withCostume(String value) {
        return new PlayerState(demon, style, school, xp, energy, energyTick, cooldowns, value);
    }
}
