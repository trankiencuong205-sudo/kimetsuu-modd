package com.kimetsu.mod;

import com.kimetsu.mod.data.ModAttachments;
import com.kimetsu.mod.item.ModItems;
import com.kimetsu.mod.network.ModNetwork;
import com.kimetsu.mod.server.ServerEvents;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Điểm vào chung (server + client). Các hệ thống được đăng ký từ đây,
 * mỗi hệ thống nằm trong package riêng:
 * data (dữ liệu người chơi), item, skill (Hơi Thở/Huyết Quỷ Thuật + hiệu ứng),
 * server (logic, quỷ), network (gói tin), client (phím tắt, HUD, menu).
 */
public class KimetsuMod implements ModInitializer {
    public static final String MOD_ID = "kimetsu";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModAttachments.init();
        ModItems.initialize();
        ModNetwork.registerPayloads();
        ModNetwork.registerReceivers();
        ServerEvents.register();
        LOGGER.info("Kimetsu mod da khoi dong (common)");
    }
}
