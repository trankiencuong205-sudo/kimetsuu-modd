package com.kimetsu.mod.skill;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Tiện ích phát hạt và âm thanh từ phía máy chủ.
 * Dùng ServerLevel.sendParticles nên mọi người chơi ở gần đều nhận được gói tin
 * hạt giống hệt nhau (đồng bộ multiplayer, không cần code render phía client).
 */
public final class Fx {
    private Fx() {
    }

    /** Một hạt bụi màu (RGB) với kích thước tùy chọn. */
    public static void dust(ServerLevel level, Vec3 v, int rgb, float size) {
        level.sendParticles(new DustParticleOptions(rgb, size), v.x, v.y, v.z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    /** Một cụm hạt vanilla đặc trưng nguyên tố. */
    public static void accent(ServerLevel level, ParticleOptions options, Vec3 v, int count, double spread) {
        level.sendParticles(options, v.x, v.y, v.z, count, spread, spread, spread, 0.02);
    }

    public static void sound(ServerLevel level, Vec3 v, String soundId, float volume, float pitch) {
        SoundEvent event = SoundEvent.createVariableRangeEvent(Identifier.parse(soundId));
        level.playSound((Player) null, v.x, v.y, v.z, event, SoundSource.PLAYERS, volume, pitch);
    }
}
