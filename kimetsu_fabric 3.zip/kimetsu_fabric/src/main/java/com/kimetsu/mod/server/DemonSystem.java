package com.kimetsu.mod.server;

import com.kimetsu.mod.data.PlayerState;
import com.kimetsu.mod.skill.Fx;
import com.kimetsu.mod.skill.SkillStyle;
import com.kimetsu.mod.skill.Skills;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.Vec3;

/**
 * Hệ thống hóa quỷ: uống máu quỷ -> trở thành quỷ, nhận ngẫu nhiên một trường
 * phái Huyết Quỷ Thuật. Quỷ mạnh hơn, hồi máu, nhìn trong đêm, nhưng cháy dưới nắng.
 * Trạng thái lưu trong PlayerState nên còn nguyên sau khi thoát game.
 */
public final class DemonSystem {
    private DemonSystem() {
    }

    public static boolean transform(ServerPlayer p) {
        PlayerState s = SkillService.state(p);
        if (s.demon()) {
            SkillService.msg(p, "msg.kimetsu.already_demon");
            return false;
        }
        SkillStyle art = Skills.ARTS.get(p.getRandom().nextInt(Skills.ARTS.size()));
        PlayerState next = s.withDemon(true, art.id());
        SkillService.set(p, next.withEnergy(next.maxEnergy(), ((ServerLevel) p.level()).getGameTime()));
        ServerLevel lv = (ServerLevel) p.level();
        Vec3 c = p.position().add(0.0, 1.0, 0.0);
        Fx.sound(lv, c, "entity.ender_dragon.growl", 1.0f, 0.8f);
        for (int i = 0; i < 40; i++) {
            double a = i * 0.5;
            Fx.dust(lv, c.add(Math.cos(a) * 1.4, i * 0.05, Math.sin(a) * 1.4), 0xB0001A, 1.6f);
        }
        p.displayClientMessage(Component.translatable("msg.kimetsu.became_demon",
                Component.translatable(art.nameKey())), false);
        return true;
    }

    public static boolean cure(ServerPlayer p) {
        PlayerState s = SkillService.state(p);
        if (!s.demon()) {
            SkillService.msg(p, "msg.kimetsu.not_demon");
            return false;
        }
        SkillService.set(p, s.withDemon(false, ""));
        ServerLevel lv = (ServerLevel) p.level();
        Fx.sound(lv, p.position(), "block.amethyst_block.chime", 1.0f, 1.0f);
        p.displayClientMessage(Component.translatable("msg.kimetsu.cured"), false);
        return true;
    }

    /** Gọi mỗi giây cho từng người chơi. */
    public static void tick(ServerPlayer p) {
        PlayerState s = SkillService.state(p);
        if (!s.demon()) {
            return;
        }
        ServerLevel lv = (ServerLevel) p.level();
        p.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 60, 0, true, false));
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false));
        p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, true, false));

        long t = lv.getDayTime() % 24000L;
        boolean day = t < 12000L;
        if (day && !p.isCreative() && lv.canSeeSky(p.blockPosition()) && !lv.isRaining() && !p.isInWater()) {
            p.setRemainingFireTicks(60);
            SkillService.msg(p, "msg.kimetsu.sun");
        }
    }
}
