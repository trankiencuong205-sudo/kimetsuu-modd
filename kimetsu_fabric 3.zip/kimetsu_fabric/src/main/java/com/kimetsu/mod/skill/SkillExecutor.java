package com.kimetsu.mod.skill;

import com.kimetsu.mod.server.TickScheduler;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Thực thi một kỹ năng trên máy chủ: tính vùng trúng, gây sát thương, áp hiệu ứng
 * phụ và phát hiệu ứng hình/âm. Mọi thứ chạy phía máy chủ.
 */
public final class SkillExecutor {
    private SkillExecutor() {
    }

    public static void cast(ServerPlayer p, ServerLevel lv, SkillDef d, int level) {
        Vec3 dir = flatDir(p);
        Vec3 o = center(p);
        float dmg = d.damage() * (1f + 0.03f * (level - 1));
        Fx.sound(lv, o, d.sound(), 1.0f, 1.0f);

        switch (d.shape()) {
            case SLASH -> slash(p, lv, d, dmg, dir, o, 0.0, 5);
            case CROSS -> {
                slash(p, lv, d, dmg * 0.6f, dir, o, 1.0, 4);
                TickScheduler.later(4, () -> {
                    if (!p.isRemoved()) {
                        slash(p, lv, d, dmg * 0.6f, flatDir(p), center(p), -1.0, 4);
                    }
                });
            }
            case SPIN -> spin(p, lv, d, dmg);
            case DASH -> dash(p, lv, d, dmg, dir);
            case LEAP -> leap(p, lv, d, dmg, dir);
            case WAVE -> wave(p, lv, d, dmg, dir, o);
            case PILLARS -> pillars(p, lv, d, dmg, dir);
            case RAIN -> rain(p, lv, d, dmg, dir);
            case SERPENT -> SnakeFx.cast(p, lv, d, dmg, dir, o);
            case AURA -> aura(p, lv, d, dmg);
        }
    }

    // ------------------------------------------------------------------ hình học

    static Vec3 flatDir(ServerPlayer p) {
        double yaw = Math.toRadians(p.getYRot());
        return new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
    }

    static Vec3 center(ServerPlayer p) {
        return p.position().add(0.0, p.getBbHeight() * 0.55, 0.0);
    }

    /** Xoay vector quanh trục Y một góc (radian). */
    static Vec3 rotY(Vec3 v, double angle) {
        double c = Math.cos(angle);
        double s = Math.sin(angle);
        return new Vec3(v.x * c - v.z * s, v.y, v.x * s + v.z * c);
    }

    static List<LivingEntity> near(ServerLevel lv, ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        List<LivingEntity> list = lv.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != p && e.isAlive() && !e.isSpectator());
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : list) {
            Vec3 ec = e.position().add(0.0, e.getBbHeight() * 0.5, 0.0);
            if (ec.distanceTo(c) <= r + e.getBbWidth() * 0.5) {
                out.add(e);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ sát thương

    /** Gây sát thương + đẩy lùi + hiệu ứng phụ lên các mục tiêu. Trả về số mục tiêu bị trúng. */
    static int strike(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg,
                      Collection<LivingEntity> targets, Vec3 fallbackDir, double knockback) {
        int hits = 0;
        for (LivingEntity t : targets) {
            if (t.hurtServer(lv, lv.damageSources().playerAttack(p), dmg)) {
                hits++;
            }
            Vec3 away = t.position().subtract(p.position());
            Vec3 flat = new Vec3(away.x, 0.0, away.z);
            flat = flat.lengthSqr() < 0.01 ? fallbackDir : flat.normalize();
            t.push(flat.x * knockback, 0.2 + knockback * 0.15, flat.z * knockback);
            t.hurtMarked = true;
            applyExtra(p, t, d);
            Vec3 tc = t.position().add(0.0, t.getBbHeight() * 0.5, 0.0);
            Fx.accent(lv, ParticleTypes.CRIT, tc, 8, 0.3);
            Fx.dust(lv, tc, d.color(), 1.6f);
        }
        return hits;
    }

    private static void applyExtra(ServerPlayer p, LivingEntity t, SkillDef d) {
        int ticks = Math.max(20, d.extraTicks());
        switch (d.extra()) {
            case IGNITE -> t.setRemainingFireTicks(ticks);
            case SLOW -> t.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, ticks, 2));
            case BLIND -> t.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, ticks, 0));
            case WEAKEN -> t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 1));
            case POISON -> t.addEffect(new MobEffectInstance(MobEffects.POISON, ticks, 1));
            case FREEZE -> {
                t.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, ticks, 4));
                t.setTicksFrozen(220);
            }
            case LIFT -> {
                t.push(0.0, 0.8, 0.0);
                t.hurtMarked = true;
            }
            default -> {
            }
        }
    }

    // ------------------------------------------------------------------ các hình dạng

    private static void slash(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg,
                              Vec3 dir, Vec3 o, double tilt, int frames) {
        double half = Math.toRadians(75.0);
        Set<LivingEntity> hit = new HashSet<>();
        for (LivingEntity t : near(lv, p, o, d.range())) {
            Vec3 to = t.position().add(0.0, t.getBbHeight() * 0.5, 0.0).subtract(o);
            Vec3 flat = new Vec3(to.x, 0.0, to.z);
            if (flat.lengthSqr() < 0.01 || flat.normalize().dot(dir) >= Math.cos(half)) {
                hit.add(t);
            }
        }
        strike(p, lv, d, dmg, hit, dir, 0.6);

        // Quét hình cung qua các khung hình để trông như một nhát chém đang vung
        TickScheduler.repeat(frames, i -> {
            double a0 = -half + (2.0 * half) * i / frames;
            double a1 = -half + (2.0 * half) * (i + 1) / frames;
            for (double a = a0; a <= a1; a += Math.toRadians(7.0)) {
                Vec3 ad = rotY(dir, a);
                double ty = tilt * (a / half) * 0.9;
                for (double r = 1.0; r <= d.range(); r += 0.55) {
                    double edge = r / d.range();
                    Vec3 pt = o.add(ad.scale(r)).add(0.0, ty * edge, 0.0);
                    Fx.dust(lv, pt, edge > 0.8 ? d.color2() : d.color(), (float) (0.9 + edge * 0.6));
                }
                Fx.accent(lv, d.accent(), o.add(ad.scale(d.range())).add(0.0, ty, 0.0), 2, 0.15);
            }
        });
        Fx.accent(lv, ParticleTypes.SWEEP_ATTACK, o.add(dir.scale(d.range() * 0.6)), 1, 0.0);
    }

    private static void spin(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg) {
        Vec3 c0 = center(p);
        strike(p, lv, d, dmg, near(lv, p, c0, d.range()), flatDir(p), 0.8);
        TickScheduler.repeat(8, i -> {
            if (p.isRemoved()) {
                return;
            }
            Vec3 c = center(p);
            double base = i * Math.PI / 4.0;
            double lift = -0.4 + i * 0.22;
            for (double a = base; a <= base + Math.PI / 4.0 + 0.05; a += 0.1) {
                for (double r = 1.2; r <= d.range(); r += 0.8) {
                    Vec3 pt = c.add(Math.cos(a) * r, lift, Math.sin(a) * r);
                    Fx.dust(lv, pt, r > d.range() - 0.9 ? d.color2() : d.color(), 1.1f);
                }
                Fx.accent(lv, d.accent(), c.add(Math.cos(a) * d.range(), lift, Math.sin(a) * d.range()), 1, 0.1);
            }
        });
    }

    private static void dash(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg, Vec3 dir) {
        double speed = d.dash() > 0 ? d.dash() : 2.0;
        p.setDeltaMovement(dir.x * speed, 0.12, dir.z * speed);
        p.hurtMarked = true;
        Set<LivingEntity> hit = new HashSet<>();
        TickScheduler.repeat(7, i -> {
            if (p.isRemoved()) {
                return;
            }
            Vec3 c = center(p);
            for (int k = 0; k < 7; k++) {
                double jitter = (lv.getRandom().nextDouble() - 0.5) * 0.5;
                Vec3 pt = c.subtract(dir.scale(k * 0.45)).add(jitter, jitter * 0.6, -jitter);
                Fx.dust(lv, pt, k % 2 == 0 ? d.color() : d.color2(), 1.3f);
            }
            Fx.accent(lv, d.accent(), c, 6, 0.4);
            List<LivingEntity> fresh = new ArrayList<>();
            for (LivingEntity t : near(lv, p, c, 2.2)) {
                if (hit.add(t)) {
                    fresh.add(t);
                }
            }
            strike(p, lv, d, dmg, fresh, dir, 0.5);
        });
    }

    private static void leap(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg, Vec3 dir) {
        p.setDeltaMovement(dir.x * 0.55, 1.05, dir.z * 0.55);
        p.hurtMarked = true;
        TickScheduler.repeat(10, i -> {
            if (p.isRemoved()) {
                return;
            }
            Vec3 c = center(p);
            for (int k = 0; k < 3; k++) {
                double a = i * 0.9 + k * 2.1;
                Fx.dust(lv, c.add(Math.cos(a) * 1.2, -0.3, Math.sin(a) * 1.2), d.color(), 1.2f);
            }
            Fx.accent(lv, d.accent(), c, 3, 0.3);
        });
        // Giáng xuống và nổ sóng xung kích
        TickScheduler.later(11, () -> {
            if (p.isRemoved()) {
                return;
            }
            p.setDeltaMovement(0.0, -1.4, 0.0);
            p.hurtMarked = true;
        });
        TickScheduler.later(14, () -> {
            if (p.isRemoved()) {
                return;
            }
            Vec3 base = p.position().add(0.0, 0.2, 0.0);
            strike(p, lv, d, dmg, near(lv, p, base, d.range()), dir, 1.1);
            Fx.sound(lv, base, "entity.generic.explode", 0.8f, 1.2f);
            Fx.accent(lv, ParticleTypes.EXPLOSION, base, 1, 0.0);
            TickScheduler.repeat(5, i -> {
                double r = d.range() * (i + 1) / 5.0;
                for (double a = 0; a < Math.PI * 2; a += 0.22) {
                    Fx.dust(lv, base.add(Math.cos(a) * r, 0.1 + i * 0.1, Math.sin(a) * r),
                            i % 2 == 0 ? d.color() : d.color2(), 1.4f);
                }
                Fx.accent(lv, d.accent(), base.add(0.0, 0.3, 0.0), 10, r * 0.4);
            });
        });
    }

    private static void wave(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg, Vec3 dir, Vec3 o) {
        double speed = 1.15;
        int ticks = Math.max(2, (int) (d.range() / speed));
        Vec3 start = o.add(dir.scale(1.2));
        Set<LivingEntity> hit = new HashSet<>();
        double radius = 2.6;
        TickScheduler.repeat(ticks, i -> {
            Vec3 c = start.add(dir.scale(i * speed));
            for (double a = -Math.toRadians(70); a <= Math.toRadians(70); a += Math.toRadians(10)) {
                Vec3 pt = c.add(rotY(dir, a).scale(radius)).subtract(dir.scale(radius));
                for (int h = 0; h < 3; h++) {
                    Fx.dust(lv, pt.add(0.0, h * 0.55 - 0.3, 0.0), h == 1 ? d.color2() : d.color(), 1.3f);
                }
            }
            Fx.accent(lv, d.accent(), c, 6, 0.8);
            Fx.accent(lv, d.accent(), c.add(0.0, -0.6, 0.0), 4, 1.2);
            List<LivingEntity> fresh = new ArrayList<>();
            for (LivingEntity t : near(lv, p, c, 2.4)) {
                if (hit.add(t)) {
                    fresh.add(t);
                }
            }
            strike(p, lv, d, dmg, fresh, dir, 0.9);
        });
    }

    private static void pillars(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg, Vec3 dir) {
        int n = Math.max(1, (int) (d.range() / 2.2));
        for (int i = 1; i <= n; i++) {
            final double dist = i * 2.2;
            TickScheduler.later(i * 2, () -> {
                if (p.isRemoved()) {
                    return;
                }
                Vec3 pos = p.position().add(dir.scale(dist));
                Fx.sound(lv, pos, "entity.evoker_fangs.attack", 0.6f, 1.0f);
                for (double h = 0.0; h <= 3.6; h += 0.4) {
                    for (int k = 0; k < 4; k++) {
                        double a = h * 2.0 + k * Math.PI / 2.0;
                        double r = 0.55 + 0.25 * Math.sin(h * 2.0);
                        Fx.dust(lv, pos.add(Math.cos(a) * r, h, Math.sin(a) * r),
                                k % 2 == 0 ? d.color() : d.color2(), 1.3f);
                    }
                }
                Fx.accent(lv, d.accent(), pos.add(0.0, 1.0, 0.0), 16, 0.6);
                Fx.accent(lv, ParticleTypes.POOF, pos, 6, 0.5);
                strike(p, lv, d, dmg, near(lv, p, pos.add(0.0, 1.0, 0.0), 1.9), dir, 0.5);
            });
        }
    }

    private static void rain(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg, Vec3 dir) {
        double radius = d.range() / 1.6;
        Vec3 c = p.position().add(dir.scale(d.range() * 0.6));
        float hitDmg = dmg / 4.0f;
        TickScheduler.repeat(20, i -> {
            for (int k = 0; k < 7; k++) {
                double a = lv.getRandom().nextDouble() * Math.PI * 2.0;
                double r = Math.sqrt(lv.getRandom().nextDouble()) * radius;
                Vec3 top = c.add(Math.cos(a) * r, 7.0, Math.sin(a) * r);
                for (int s = 0; s < 6; s++) {
                    Fx.dust(lv, top.add(0.0, -s * 1.1, 0.0), s % 2 == 0 ? d.color() : d.color2(), 0.8f);
                }
                Vec3 ground = c.add(Math.cos(a) * r, 0.1, Math.sin(a) * r);
                Fx.accent(lv, d.accent(), ground, 2, 0.15);
            }
            if (i % 5 == 0) {
                Fx.sound(lv, c, d.sound(), 0.5f, 1.3f);
                strike(p, lv, d, hitDmg, near(lv, p, c.add(0.0, 1.0, 0.0), radius), dir, 0.3);
            }
        });
    }

    private static void aura(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg) {
        TickScheduler.repeat(20, i -> {
            if (p.isRemoved()) {
                return;
            }
            Vec3 c = p.position();
            for (int k = 0; k < 3; k++) {
                double a = i * 0.5 + k * 2.1;
                double r = 1.3 + 0.2 * Math.sin(i * 0.4);
                Fx.dust(lv, c.add(Math.cos(a) * r, i * 0.11, Math.sin(a) * r),
                        k == 0 ? d.color2() : d.color(), 1.3f);
            }
            Fx.accent(lv, d.accent(), c.add(0.0, 1.0, 0.0), 3, 0.5);
        });
        switch (d.extra()) {
            case GUARD -> p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, Math.max(60, d.extraTicks()), 1));
            case HEAL -> {
                p.heal(dmg);
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            }
            default -> strike(p, lv, d, dmg, near(lv, p, center(p), d.range()), flatDir(p), 0.4);
        }
    }
}
