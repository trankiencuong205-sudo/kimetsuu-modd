package com.kimetsu.mod.server;

import com.kimetsu.mod.data.PlayerState;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Enemy;

/** Các sự kiện phía máy chủ: tick hiệu ứng, tick quỷ, kinh nghiệm khi hạ mục tiêu. */
public final class ServerEvents {
    private ServerEvents() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            TickScheduler.tick();
            if (server.getTickCount() % 20 == 0) {
                for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                    DemonSystem.tick(p);
                }
            }
        });

        // Kinh nghiệm (luyện tập): hạ quái cho nhiều XP hơn hạ sinh vật thường
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.getEntity() instanceof ServerPlayer killer && entity != killer) {
                SkillService.addXp(killer, entity instanceof Enemy ? 12 : 4);
                PlayerState s = SkillService.state(killer);
                if (s.demon()) {
                    // Quỷ hồi máu và năng lượng khi hạ mục tiêu
                    killer.heal(4.0f);
                    long now = ((ServerLevel) killer.level()).getGameTime();
                    SkillService.set(killer, s.withEnergy(Math.min(s.maxEnergy(), s.energyAt(now) + 20f), now));
                }
            }
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> TickScheduler.clear());
    }
}
