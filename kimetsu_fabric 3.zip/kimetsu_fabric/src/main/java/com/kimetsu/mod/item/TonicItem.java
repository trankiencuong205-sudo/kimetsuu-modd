package com.kimetsu.mod.item;

import com.kimetsu.mod.server.DemonSystem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Tinh chất Tử Đằng: chuột phải để trở lại làm người. */
public class TonicItem extends Item {
    public TonicItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer sp) {
            if (DemonSystem.cure(sp)) {
                player.getItemInHand(hand).consume(1, player);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
