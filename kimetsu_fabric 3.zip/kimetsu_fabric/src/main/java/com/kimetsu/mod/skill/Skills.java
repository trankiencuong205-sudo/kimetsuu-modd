package com.kimetsu.mod.skill;

import java.util.List;
import net.minecraft.core.particles.ParticleTypes;

/**
 * Danh mục toàn bộ Hơi Thở và Huyết Quỷ Thuật.
 * FILE NÀY ĐƯỢC SINH TỰ ĐỘNG từ bảng dữ liệu kỹ năng cùng với file ngôn ngữ,
 * nên chỉ số và tên luôn khớp nhau. Muốn đổi sát thương, tầm, năng lượng, hồi chiêu
 * thì sửa trực tiếp các con số ở đây (thứ tự: sát thương, tầm, năng lượng, hồi chiêu tick, cấp mở khóa).
 */
public final class Skills {
    private Skills() {
    }

    private static SkillDef d(String id, SkillShape shape, float damage, float range, float cost,
                              int cooldown, int minLevel, int color, int color2,
                              net.minecraft.core.particles.ParticleOptions accent, String sound,
                              Extra extra, int extraTicks, double dash, int count) {
        return new SkillDef(id, shape, damage, range, cost, cooldown, minLevel, color, color2,
                accent, sound, extra, extraTicks, dash, count);
    }

    /** 9 Hơi Thở, mỗi Hơi Thở 5 thức. */
    public static final List<SkillStyle> BREATHINGS = List.of(
            new SkillStyle("water", false, 0x2F7CFF, List.of(
                d("water_1", SkillShape.SLASH, 6.0f, 4.5f, 15.0f, 60, 1, 0x2F7CFF, 0xBFE6FF, ParticleTypes.SPLASH, "entity.player.attack.sweep", Extra.NONE, 0, 0.0, 0),
                d("water_2", SkillShape.SPIN, 7.0f, 4.5f, 20.0f, 100, 3, 0x2F7CFF, 0xBFE6FF, ParticleTypes.BUBBLE, "item.trident.riptide_3", Extra.SLOW, 60, 0.0, 0),
                d("water_3", SkillShape.RAIN, 9.0f, 7.0f, 28.0f, 160, 6, 0x2F7CFF, 0xBFE6FF, ParticleTypes.SPLASH, "item.trident.riptide_1", Extra.SLOW, 40, 0.0, 0),
                d("water_4", SkillShape.LEAP, 13.0f, 5.0f, 35.0f, 200, 9, 0x2F7CFF, 0xBFE6FF, ParticleTypes.SPLASH, "entity.player.attack.strong", Extra.SLOW, 60, 0.0, 0),
                d("water_5", SkillShape.WAVE, 16.0f, 13.0f, 50.0f, 320, 12, 0x2F7CFF, 0xBFE6FF, ParticleTypes.BUBBLE, "item.trident.riptide_3", Extra.SLOW, 80, 0.0, 0)
            )),
            new SkillStyle("flame", false, 0xFF5A1E, List.of(
                d("flame_1", SkillShape.SLASH, 7.0f, 4.5f, 15.0f, 60, 1, 0xFF5A1E, 0xFFC24A, ParticleTypes.FLAME, "item.firecharge.use", Extra.IGNITE, 80, 0.0, 0),
                d("flame_2", SkillShape.PILLARS, 9.0f, 10.0f, 25.0f, 140, 3, 0xFF5A1E, 0xFFC24A, ParticleTypes.FLAME, "entity.blaze.shoot", Extra.IGNITE, 100, 0.0, 0),
                d("flame_3", SkillShape.SPIN, 9.0f, 5.0f, 28.0f, 160, 6, 0xFF5A1E, 0xFFC24A, ParticleTypes.FLAME, "item.firecharge.use", Extra.IGNITE, 100, 0.0, 0),
                d("flame_4", SkillShape.WAVE, 14.0f, 14.0f, 40.0f, 240, 9, 0xFF5A1E, 0xFFC24A, ParticleTypes.FLAME, "entity.blaze.shoot", Extra.IGNITE, 120, 0.0, 0),
                d("flame_5", SkillShape.LEAP, 20.0f, 6.0f, 55.0f, 360, 12, 0xFF5A1E, 0xFFC24A, ParticleTypes.LAVA, "entity.generic.explode", Extra.IGNITE, 160, 0.0, 0)
            )),
            new SkillStyle("thunder", false, 0xFFE94A, List.of(
                d("thunder_1", SkillShape.DASH, 7.0f, 4.0f, 15.0f, 60, 1, 0xFFE94A, 0xFFFFFF, ParticleTypes.ELECTRIC_SPARK, "entity.lightning_bolt.impact", Extra.NONE, 0, 2.1, 0),
                d("thunder_2", SkillShape.CROSS, 9.0f, 5.0f, 22.0f, 120, 3, 0xFFE94A, 0xFFFFFF, ParticleTypes.ELECTRIC_SPARK, "entity.lightning_bolt.impact", Extra.SLOW, 30, 0.0, 0),
                d("thunder_3", SkillShape.SPIN, 10.0f, 5.0f, 28.0f, 160, 6, 0xFFE94A, 0xFFFFFF, ParticleTypes.ELECTRIC_SPARK, "entity.lightning_bolt.impact", Extra.SLOW, 60, 0.0, 0),
                d("thunder_4", SkillShape.DASH, 14.0f, 4.0f, 40.0f, 200, 9, 0xFFE94A, 0xFFFFFF, ParticleTypes.ELECTRIC_SPARK, "entity.lightning_bolt.thunder", Extra.SLOW, 40, 3.2, 0),
                d("thunder_5", SkillShape.RAIN, 22.0f, 7.0f, 55.0f, 360, 12, 0xFFE94A, 0xFFFFFF, ParticleTypes.ELECTRIC_SPARK, "entity.lightning_bolt.thunder", Extra.SLOW, 80, 0.0, 0)
            )),
            new SkillStyle("wind", false, 0x8CFFC8, List.of(
                d("wind_1", SkillShape.SLASH, 6.0f, 5.0f, 14.0f, 60, 1, 0x8CFFC8, 0xFFFFFF, ParticleTypes.CLOUD, "entity.player.attack.sweep", Extra.LIFT, 0, 0.0, 0),
                d("wind_2", SkillShape.SPIN, 8.0f, 5.0f, 22.0f, 120, 3, 0x8CFFC8, 0xFFFFFF, ParticleTypes.CLOUD, "entity.phantom.swoop", Extra.LIFT, 0, 0.0, 0),
                d("wind_3", SkillShape.CROSS, 10.0f, 5.5f, 28.0f, 160, 6, 0x8CFFC8, 0xFFFFFF, ParticleTypes.CLOUD, "entity.player.attack.sweep", Extra.NONE, 0, 0.0, 0),
                d("wind_4", SkillShape.WAVE, 13.0f, 14.0f, 38.0f, 240, 9, 0x8CFFC8, 0xFFFFFF, ParticleTypes.CLOUD, "entity.ender_dragon.flap", Extra.LIFT, 0, 0.0, 0),
                d("wind_5", SkillShape.LEAP, 18.0f, 6.5f, 52.0f, 320, 12, 0x8CFFC8, 0xFFFFFF, ParticleTypes.CLOUD, "entity.phantom.swoop", Extra.LIFT, 0, 0.0, 0)
            )),
            new SkillStyle("stone", false, 0xA8977A, List.of(
                d("stone_1", SkillShape.PILLARS, 8.0f, 8.0f, 18.0f, 100, 1, 0xA8977A, 0x6B5B45, ParticleTypes.CRIT, "block.anvil.land", Extra.LIFT, 0, 0.0, 0),
                d("stone_2", SkillShape.LEAP, 12.0f, 5.0f, 28.0f, 160, 3, 0xA8977A, 0x6B5B45, ParticleTypes.CRIT, "block.anvil.land", Extra.SLOW, 40, 0.0, 0),
                d("stone_3", SkillShape.AURA, 0.0f, 4.0f, 25.0f, 280, 6, 0xA8977A, 0x6B5B45, ParticleTypes.CRIT, "block.anvil.land", Extra.GUARD, 200, 0.0, 0),
                d("stone_4", SkillShape.PILLARS, 16.0f, 12.0f, 42.0f, 220, 9, 0xA8977A, 0x6B5B45, ParticleTypes.CRIT, "block.anvil.land", Extra.LIFT, 0, 0.0, 0),
                d("stone_5", SkillShape.RAIN, 24.0f, 8.0f, 60.0f, 400, 12, 0xA8977A, 0x6B5B45, ParticleTypes.CRIT, "entity.generic.explode", Extra.SLOW, 80, 0.0, 0)
            )),
            new SkillStyle("serpent", false, 0x4CD13A, List.of(
                d("serpent_1", SkillShape.SERPENT, 7.0f, 14.0f, 15.0f, 60, 1, 0x4CD13A, 0x1B5E20, ParticleTypes.SMOKE, "entity.phantom.swoop", Extra.POISON, 60, 0.0, 1),
                d("serpent_2", SkillShape.SERPENT, 8.0f, 14.0f, 22.0f, 120, 3, 0x4CD13A, 0x1B5E20, ParticleTypes.SMOKE, "entity.phantom.swoop", Extra.POISON, 80, 0.0, 2),
                d("serpent_3", SkillShape.SERPENT, 8.0f, 11.0f, 32.0f, 200, 6, 0x4CD13A, 0x1B5E20, ParticleTypes.SMOKE, "entity.phantom.swoop", Extra.POISON, 80, 0.0, -5),
                d("serpent_4", SkillShape.SERPENT, 10.0f, 18.0f, 40.0f, 240, 9, 0x4CD13A, 0x1B5E20, ParticleTypes.SMOKE, "entity.phantom.swoop", Extra.POISON, 120, 0.0, 3),
                d("serpent_5", SkillShape.SERPENT, 12.0f, 20.0f, 58.0f, 400, 12, 0x4CD13A, 0x1B5E20, ParticleTypes.SMOKE, "entity.phantom.swoop", Extra.POISON, 160, 0.0, 7)
            )),
            new SkillStyle("mist", false, 0xE8F1FF, List.of(
                d("mist_1", SkillShape.SLASH, 6.0f, 5.0f, 14.0f, 60, 1, 0xE8F1FF, 0xB0C4DE, ParticleTypes.CLOUD, "entity.player.attack.sweep", Extra.BLIND, 40, 0.0, 0),
                d("mist_2", SkillShape.DASH, 8.0f, 4.0f, 18.0f, 100, 3, 0xE8F1FF, 0xB0C4DE, ParticleTypes.CLOUD, "entity.enderman.teleport", Extra.BLIND, 40, 2.4, 0),
                d("mist_3", SkillShape.SPIN, 8.0f, 6.0f, 26.0f, 180, 6, 0xE8F1FF, 0xB0C4DE, ParticleTypes.CLOUD, "entity.phantom.swoop", Extra.BLIND, 80, 0.0, 0),
                d("mist_4", SkillShape.RAIN, 12.0f, 8.0f, 36.0f, 240, 9, 0xE8F1FF, 0xB0C4DE, ParticleTypes.CLOUD, "block.amethyst_block.chime", Extra.BLIND, 60, 0.0, 0),
                d("mist_5", SkillShape.WAVE, 15.0f, 14.0f, 48.0f, 300, 12, 0xE8F1FF, 0xB0C4DE, ParticleTypes.CLOUD, "entity.ender_dragon.flap", Extra.BLIND, 100, 0.0, 0)
            )),
            new SkillStyle("flower", false, 0xFF8FC8, List.of(
                d("flower_1", SkillShape.SLASH, 6.0f, 4.5f, 14.0f, 60, 1, 0xFF8FC8, 0xFFD1E8, ParticleTypes.CHERRY_LEAVES, "entity.player.attack.sweep", Extra.NONE, 0, 0.0, 0),
                d("flower_2", SkillShape.CROSS, 9.0f, 5.0f, 24.0f, 140, 3, 0xFF8FC8, 0xFFD1E8, ParticleTypes.CHERRY_LEAVES, "entity.player.attack.sweep", Extra.NONE, 0, 0.0, 0),
                d("flower_3", SkillShape.SPIN, 9.0f, 5.0f, 26.0f, 160, 6, 0xFF8FC8, 0xFFD1E8, ParticleTypes.CHERRY_LEAVES, "block.amethyst_block.chime", Extra.WEAKEN, 60, 0.0, 0),
                d("flower_4", SkillShape.RAIN, 12.0f, 7.5f, 36.0f, 220, 9, 0xFF8FC8, 0xFFD1E8, ParticleTypes.CHERRY_LEAVES, "block.amethyst_block.chime", Extra.WEAKEN, 80, 0.0, 0),
                d("flower_5", SkillShape.AURA, 6.0f, 6.0f, 45.0f, 400, 12, 0xFF8FC8, 0xFFD1E8, ParticleTypes.HEART, "block.amethyst_block.chime", Extra.HEAL, 0, 0.0, 0)
            )),
            new SkillStyle("sound", false, 0xFFD34A, List.of(
                d("sound_1", SkillShape.WAVE, 8.0f, 9.0f, 16.0f, 80, 1, 0xFFD34A, 0x9A5CFF, ParticleTypes.NOTE, "block.note_block.basedrum", Extra.SLOW, 20, 0.0, 0),
                d("sound_2", SkillShape.SPIN, 9.0f, 5.0f, 24.0f, 140, 3, 0xFFD34A, 0x9A5CFF, ParticleTypes.NOTE, "block.note_block.bell", Extra.WEAKEN, 50, 0.0, 0),
                d("sound_3", SkillShape.PILLARS, 12.0f, 11.0f, 34.0f, 200, 6, 0xFFD34A, 0x9A5CFF, ParticleTypes.NOTE, "entity.warden.sonic_boom", Extra.LIFT, 0, 0.0, 0),
                d("sound_4", SkillShape.RAIN, 14.0f, 7.0f, 42.0f, 260, 9, 0xFFD34A, 0x9A5CFF, ParticleTypes.NOTE, "block.bell.use", Extra.SLOW, 60, 0.0, 0),
                d("sound_5", SkillShape.LEAP, 22.0f, 6.5f, 58.0f, 360, 12, 0xFFD34A, 0x9A5CFF, ParticleTypes.NOTE, "entity.warden.sonic_boom", Extra.WEAKEN, 100, 0.0, 0)
            ))
    );

    /** 6 trường phái Huyết Quỷ Thuật, mỗi trường phái 3 kỹ năng. */
    public static final List<SkillStyle> ARTS = List.of(
            new SkillStyle("blood", true, 0xB0001A, List.of(
                d("blood_1", SkillShape.SLASH, 7.0f, 5.0f, 12.0f, 60, 1, 0xB0001A, 0x4A0008, ParticleTypes.CRIT, "entity.player.attack.sweep", Extra.NONE, 0, 0.0, 0),
                d("blood_2", SkillShape.RAIN, 12.0f, 7.0f, 30.0f, 180, 5, 0xB0001A, 0x4A0008, ParticleTypes.CRIT, "entity.wither.shoot", Extra.WEAKEN, 60, 0.0, 0),
                d("blood_3", SkillShape.WAVE, 18.0f, 14.0f, 48.0f, 280, 10, 0xB0001A, 0x4A0008, ParticleTypes.CRIT, "entity.wither.shoot", Extra.SLOW, 60, 0.0, 0)
            )),
            new SkillStyle("thread", true, 0xFFFFFF, List.of(
                d("thread_1", SkillShape.CROSS, 8.0f, 6.0f, 14.0f, 80, 1, 0xFFFFFF, 0xBDBDBD, ParticleTypes.END_ROD, "entity.player.attack.sweep", Extra.SLOW, 30, 0.0, 0),
                d("thread_2", SkillShape.SPIN, 10.0f, 6.0f, 28.0f, 160, 5, 0xFFFFFF, 0xBDBDBD, ParticleTypes.END_ROD, "entity.phantom.swoop", Extra.SLOW, 100, 0.0, 0),
                d("thread_3", SkillShape.PILLARS, 15.0f, 11.0f, 45.0f, 280, 10, 0xFFFFFF, 0xBDBDBD, ParticleTypes.END_ROD, "entity.evoker_fangs.attack", Extra.SLOW, 120, 0.0, 0)
            )),
            new SkillStyle("illusion", true, 0xA040FF, List.of(
                d("illusion_1", SkillShape.AURA, 4.0f, 6.0f, 20.0f, 160, 1, 0xA040FF, 0x3A1070, ParticleTypes.ENCHANT, "entity.evoker.cast_spell", Extra.BLIND, 80, 0.0, 0),
                d("illusion_2", SkillShape.DASH, 10.0f, 4.0f, 24.0f, 120, 5, 0xA040FF, 0x3A1070, ParticleTypes.SCULK_SOUL, "entity.enderman.teleport", Extra.WEAKEN, 60, 2.6, 0),
                d("illusion_3", SkillShape.SPIN, 16.0f, 6.0f, 44.0f, 260, 10, 0xA040FF, 0x3A1070, ParticleTypes.SCULK_SOUL, "entity.elder_guardian.curse", Extra.BLIND, 120, 0.0, 0)
            )),
            new SkillStyle("flesh", true, 0xC8806A, List.of(
                d("flesh_1", SkillShape.PILLARS, 10.0f, 9.0f, 18.0f, 100, 1, 0xC8806A, 0x7A1020, ParticleTypes.LARGE_SMOKE, "entity.evoker_fangs.attack", Extra.LIFT, 0, 0.0, 0),
                d("flesh_2", SkillShape.LEAP, 14.0f, 5.0f, 30.0f, 180, 5, 0xC8806A, 0x7A1020, ParticleTypes.LARGE_SMOKE, "entity.phantom.swoop", Extra.NONE, 0, 0.0, 0),
                d("flesh_3", SkillShape.AURA, 8.0f, 6.0f, 40.0f, 320, 10, 0xC8806A, 0x7A1020, ParticleTypes.HEART, "entity.evoker.cast_spell", Extra.HEAL, 0, 0.0, 0)
            )),
            new SkillStyle("frost", true, 0x9FE8FF, List.of(
                d("frost_1", SkillShape.SPIN, 8.0f, 5.0f, 18.0f, 100, 1, 0x9FE8FF, 0xFFFFFF, ParticleTypes.SNOWFLAKE, "block.glass.break", Extra.FREEZE, 120, 0.0, 0),
                d("frost_2", SkillShape.WAVE, 14.0f, 14.0f, 34.0f, 200, 5, 0x9FE8FF, 0xFFFFFF, ParticleTypes.SNOWFLAKE, "block.glass.break", Extra.FREEZE, 140, 0.0, 0),
                d("frost_3", SkillShape.PILLARS, 18.0f, 12.0f, 50.0f, 300, 10, 0x9FE8FF, 0xFFFFFF, ParticleTypes.SNOWFLAKE, "block.glass.break", Extra.FREEZE, 200, 0.0, 0)
            )),
            new SkillStyle("volley", true, 0xFF7A00, List.of(
                d("volley_1", SkillShape.RAIN, 11.0f, 7.0f, 24.0f, 140, 1, 0xFF7A00, 0x401000, ParticleTypes.FLAME, "entity.blaze.shoot", Extra.IGNITE, 80, 0.0, 0),
                d("volley_2", SkillShape.WAVE, 16.0f, 16.0f, 36.0f, 220, 5, 0xFF7A00, 0x401000, ParticleTypes.FLAME, "item.crossbow.shoot", Extra.IGNITE, 100, 0.0, 0),
                d("volley_3", SkillShape.SPIN, 18.0f, 6.5f, 48.0f, 280, 10, 0xFF7A00, 0x401000, ParticleTypes.SOUL_FIRE_FLAME, "entity.generic.explode", Extra.IGNITE, 160, 0.0, 0)
            ))
    );

    public static SkillStyle breathing(String id) {
        for (SkillStyle s : BREATHINGS) {
            if (s.id().equals(id)) {
                return s;
            }
        }
        return BREATHINGS.get(0);
    }

    public static SkillStyle art(String id) {
        for (SkillStyle s : ARTS) {
            if (s.id().equals(id)) {
                return s;
            }
        }
        return ARTS.get(0);
    }

    public static int breathingIndex(String id) {
        for (int i = 0; i < BREATHINGS.size(); i++) {
            if (BREATHINGS.get(i).id().equals(id)) {
                return i;
            }
        }
        return 0;
    }
}
