package com.kimetsu.mod.server;

import com.kimetsu.mod.KimetsuMod;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

/**
 * Bộ lập lịch theo tick của máy chủ. Hiệu ứng nhiều khung hình (nhát chém quét,
 * rắn bò, sóng bay) chạy qua đây, nên mọi hạt đều do máy chủ phát và người chơi
 * khác trong multiplayer cũng thấy đúng cùng một hiệu ứng.
 */
public final class TickScheduler {

    /** Trả về true khi tác vụ đã xong và có thể bị gỡ. */
    public interface Task {
        boolean tick();
    }

    private static final List<Task> ACTIVE = new ArrayList<>();
    private static final List<Task> PENDING = new ArrayList<>();

    private TickScheduler() {
    }

    public static void add(Task task) {
        PENDING.add(task);
    }

    /** Chạy một lần sau {@code delay} tick (delay >= 1). */
    public static void later(int delay, Runnable action) {
        int[] left = {Math.max(1, delay)};
        add(() -> {
            left[0]--;
            if (left[0] <= 0) {
                action.run();
                return true;
            }
            return false;
        });
    }

    /** Gọi fn(0) ngay lập tức, rồi fn(1)..fn(times-1) ở các tick kế tiếp. */
    public static void repeat(int times, IntConsumer fn) {
        fn.accept(0);
        if (times <= 1) {
            return;
        }
        int[] index = {1};
        add(() -> {
            fn.accept(index[0]);
            index[0]++;
            return index[0] >= times;
        });
    }

    public static void tick() {
        if (!PENDING.isEmpty()) {
            ACTIVE.addAll(PENDING);
            PENDING.clear();
        }
        for (int i = ACTIVE.size() - 1; i >= 0; i--) {
            boolean done;
            try {
                done = ACTIVE.get(i).tick();
            } catch (Throwable t) {
                KimetsuMod.LOGGER.error("Loi trong tac vu hieu ung", t);
                done = true;
            }
            if (done) {
                ACTIVE.remove(i);
            }
        }
    }

    public static void clear() {
        ACTIVE.clear();
        PENDING.clear();
    }
}
