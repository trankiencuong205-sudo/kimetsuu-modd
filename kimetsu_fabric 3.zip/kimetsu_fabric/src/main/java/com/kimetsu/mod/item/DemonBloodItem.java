package com.kimetsu.mod.item;

import com.kimetsu.mod.server.DemonSystem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Máu quỷ: chuột phải để uống và hóa quỷ. */
public class DemonBloodItem extends Item {
    public DemonBloodItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer sp) {
            if (DemonSystem.transform(sp)) {
                player.getItemInHand(hand).consume(1, player);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
