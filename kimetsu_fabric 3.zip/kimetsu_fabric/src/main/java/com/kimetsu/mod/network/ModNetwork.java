package com.kimetsu.mod.network;

import com.kimetsu.mod.KimetsuMod;
import com.kimetsu.mod.server.SkillService;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Các gói tin client -> server. Client chỉ gửi "ý định" (bấm phím nào); toàn bộ
 * kiểm tra năng lượng, hồi chiêu, cấp độ và sát thương đều do máy chủ quyết định
 * nên không thể gian lận từ phía client.
 */
public final class ModNetwork {
    private ModNetwork() {
    }

    /** Dùng kỹ năng ở ô số {@code slot} (0..4). */
    public record UseSkill(int slot) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<UseSkill> TYPE = new CustomPacketPayload.Type<>(
                Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "use_skill"));
        public static final StreamCodec<RegistryFriendlyByteBuf, UseSkill> CODEC =
                StreamCodec.composite(ByteBufCodecs.INT, UseSkill::slot, UseSkill::new);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Đổi Hơi Thở hiện tại: dir = +1 (kế tiếp) hoặc -1 (trước đó). */
    public record CycleStyle(int dir) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<CycleStyle> TYPE = new CustomPacketPayload.Type<>(
                Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "cycle_style"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CycleStyle> CODEC =
                StreamCodec.composite(ByteBufCodecs.INT, CycleStyle::dir, CycleStyle::new);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Mặc một trang phục theo id. */
    public record EquipCostume(String id) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<EquipCostume> TYPE = new CustomPacketPayload.Type<>(
                Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "equip_costume"));
        public static final StreamCodec<RegistryFriendlyByteBuf, EquipCostume> CODEC =
                StreamCodec.composite(ByteBufCodecs.STRING_UTF8, EquipCostume::id, EquipCostume::new);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Phải gọi ở cả client lẫn server (đặt trong ModInitializer chung). */
    public static void registerPayloads() {
        PayloadTypeRegistry.playC2S().register(UseSkill.TYPE, UseSkill.CODEC);
        PayloadTypeRegistry.playC2S().register(CycleStyle.TYPE, CycleStyle.CODEC);
        PayloadTypeRegistry.playC2S().register(EquipCostume.TYPE, EquipCostume.CODEC);
    }

    public static void registerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(UseSkill.TYPE,
                (payload, context) -> SkillService.use(context.player(), payload.slot()));
        ServerPlayNetworking.registerGlobalReceiver(CycleStyle.TYPE,
                (payload, context) -> SkillService.cycleStyle(context.player(), payload.dir()));
        ServerPlayNetworking.registerGlobalReceiver(EquipCostume.TYPE,
                (payload, context) -> SkillService.equipCostume(context.player(), payload.id()));
    }
}
