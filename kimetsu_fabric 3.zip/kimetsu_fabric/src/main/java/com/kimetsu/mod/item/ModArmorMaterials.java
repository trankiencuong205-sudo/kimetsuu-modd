package com.kimetsu.mod.item;

import com.kimetsu.mod.KimetsuMod;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

/**
 * Chất liệu giáp: đồng phục Sát Quỷ Đoàn (có giáp thật) và trang phục thẩm mỹ (giáp 0).
 * Cú pháp lấy từ docs Fabric 1.21.11 (custom armor).
 */
public final class ModArmorMaterials {
    public static final int BASE_DURABILITY = 25;
    public static final int COSMETIC_DURABILITY = 60;

    /** Khớp với file assets/kimetsu/equipment/kimetsu_uniform.json */
    public static final ResourceKey<EquipmentAsset> UNIFORM_KEY = key("kimetsu_uniform");

    /** Tag sửa chữa: data/kimetsu/tags/item/repairs_uniform.json */
    public static final TagKey<Item> REPAIRS_UNIFORM = TagKey.create(
            BuiltInRegistries.ITEM.key(),
            Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "repairs_uniform"));

    // Tham số: độ bền gốc, giáp từng phần, độ phù phép, âm thanh mặc,
    // độ cứng, kháng đẩy lùi, tag sửa chữa, khóa equipment asset.
    public static final ArmorMaterial UNIFORM = new ArmorMaterial(
            BASE_DURABILITY,
            Map.of(
                    ArmorType.BOOTS, 2,
                    ArmorType.LEGGINGS, 4,
                    ArmorType.CHESTPLATE, 5,
                    ArmorType.HELMET, 2
            ),
            15,
            SoundEvents.ARMOR_EQUIP_LEATHER,
            0.0F,
            0.0F,
            REPAIRS_UNIFORM,
            UNIFORM_KEY
    );

    private static ResourceKey<EquipmentAsset> key(String name) {
        return ResourceKey.create(EquipmentAssets.ROOT_ID,
                Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, name));
    }

    /** Chất liệu thẩm mỹ: không cộng giáp, mỗi trang phục có equipment asset riêng cùng tên. */
    public static ArmorMaterial cosmetic(String name) {
        return new ArmorMaterial(
                COSMETIC_DURABILITY,
                Map.of(
                        ArmorType.BOOTS, 0,
                        ArmorType.LEGGINGS, 0,
                        ArmorType.CHESTPLATE, 0,
                        ArmorType.HELMET, 0
                ),
                10,
                SoundEvents.ARMOR_EQUIP_LEATHER,
                0.0F,
                0.0F,
                REPAIRS_UNIFORM,
                key(name)
        );
    }

    private ModArmorMaterials() {
    }
}
