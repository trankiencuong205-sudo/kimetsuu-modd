package com.kimetsu.mod.server;

import com.kimetsu.mod.data.ModAttachments;
import com.kimetsu.mod.data.PlayerState;
import com.kimetsu.mod.item.Costumes;
import com.kimetsu.mod.item.ModItems;
import com.kimetsu.mod.skill.SkillDef;
import com.kimetsu.mod.skill.SkillExecutor;
import com.kimetsu.mod.skill.SkillStyle;
import com.kimetsu.mod.skill.Skills;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Logic phía máy chủ cho việc dùng kỹ năng, đổi Hơi Thở, kinh nghiệm và trang phục.
 * Mọi kiểm tra (cấp, năng lượng, hồi chiêu, vũ khí) đều ở đây.
 */
public final class SkillService {
    private SkillService() {
    }

    public static PlayerState state(ServerPlayer p) {
        return p.getAttachedOrElse(ModAttachments.STATE, PlayerState.DEFAULT);
    }

    public static void set(ServerPlayer p, PlayerState s) {
        p.setAttached(ModAttachments.STATE, s);
    }

    public static void msg(ServerPlayer p, String key, Object... args) {
        p.displayClientMessage(Component.translatable(key, args), true);
    }

    /** Kỹ năng hiện có của người chơi: Huyết Quỷ Thuật nếu là quỷ, ngược lại là Hơi Thở đang chọn. */
    public static SkillStyle currentStyle(PlayerState s) {
        return s.demon() ? Skills.art(s.school()) : Skills.breathing(s.style());
    }

    public static void use(ServerPlayer p, int slot) {
        PlayerState s = state(p);
        SkillStyle style = currentStyle(s);
        if (slot < 0 || slot >= style.skills().size()) {
            return;
        }
        SkillDef d = style.skills().get(slot);
        ServerLevel lv = (ServerLevel) p.level();
        long now = lv.getGameTime();

        if (!s.demon() && !p.getMainHandItem().is(ModItems.NICHIRIN_SWORD)) {
            msg(p, "msg.kimetsu.need_sword");
            return;
        }
        if (s.level() < d.minLevel()) {
            msg(p, "msg.kimetsu.locked", d.minLevel());
            return;
        }
        if (!s.ready(d.id(), now)) {
            msg(p, "msg.kimetsu.cooldown");
            return;
        }
        if (s.energyAt(now) < d.cost()) {
            msg(p, "msg.kimetsu.no_energy");
            return;
        }

        int levelBefore = s.level();
        PlayerState next = s.spend(d.cost(), now)
                .withCooldown(d.id(), now + d.cooldown(), now)
                .withXp(s.xp() + 3);
        set(p, next);
        if (next.level() > levelBefore) {
            msg(p, "msg.kimetsu.level_up", next.level());
        }
        SkillExecutor.cast(p, lv, d, next.level());
    }

    public static void cycleStyle(ServerPlayer p, int dir) {
        PlayerState s = state(p);
        if (s.demon()) {
            msg(p, "msg.kimetsu.demon_no_breath");
            return;
        }
        int n = Skills.BREATHINGS.size();
        int idx = Math.floorMod(Skills.breathingIndex(s.style()) + (dir >= 0 ? 1 : -1), n);
        SkillStyle next = Skills.BREATHINGS.get(idx);
        set(p, s.withStyle(next.id()));
        msg(p, "msg.kimetsu.style_set", Component.translatable(next.nameKey()));
    }

    public static void addXp(ServerPlayer p, int amount) {
        PlayerState s = state(p);
        int before = s.level();
        PlayerState next = s.withXp(s.xp() + amount);
        set(p, next);
        if (next.level() > before) {
            msg(p, "msg.kimetsu.level_up", next.level());
        }
    }

    /** Mặc trang phục vào đúng ô giáp; món đang mặc được trả về túi đồ. */
    public static void equipCostume(ServerPlayer p, String id) {
        Costumes.Costume c = Costumes.find(id);
        if (c == null) {
            return;
        }
        ItemStack old = p.getItemBySlot(c.slot());
        p.setItemSlot(c.slot(), new ItemStack(c.item()));
        if (!old.isEmpty() && !old.is(c.item())) {
            if (!p.getInventory().add(old)) {
                p.drop(old, false);
            }
        }
        set(p, state(p).withCostume(id));
        msg(p, "msg.kimetsu.equipped", Component.translatable("item.kimetsu." + id));
    }
}
