package com.kimetsu.mod.skill;

import com.kimetsu.mod.server.TickScheduler;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Hơi Thở Rắn: những con rắn uốn lượn thật sự (đầu, thân nhiều đốt đổi màu,
 * mắt đỏ, lưỡi thè) bò theo đường sin và tự đuổi mục tiêu gần nhất.
 *
 * Lưu ý: rắn được dựng bằng hạt ở phía máy chủ, không phải entity có model 3D.
 * Cách này đồng bộ multiplayer tự động và không cần code render phía client.
 */
public final class SnakeFx {
    private static final double SPEED = 0.8;
    private static final int BODY_SEGMENTS = 16;

    private SnakeFx() {
    }

    public static void cast(ServerPlayer p, ServerLevel lv, SkillDef d, float dmg, Vec3 dir, Vec3 o) {
        int n = Math.max(1, Math.abs(d.count()));
        boolean ring = d.count() < 0;
        for (int k = 0; k < n; k++) {
            double angle;
            if (ring) {
                angle = 2.0 * Math.PI * k / n;
            } else if (n == 1) {
                angle = 0.0;
            } else {
                angle = -0.8 + 1.6 * k / (n - 1);
            }
            Vec3 heading = SkillExecutor.rotY(dir, angle);
            Vec3 start = o.add(heading.scale(1.0));
            final int index = k;
            int delay = 1 + k * 2;
            TickScheduler.later(delay, () -> {
                if (!p.isRemoved()) {
                    TickScheduler.add(new Snake(p, lv, d, dmg, start, heading, index));
                }
            });
        }
    }

    private static final class Snake implements TickScheduler.Task {
        private final ServerPlayer owner;
        private final ServerLevel lv;
        private final SkillDef d;
        private final float dmg;
        private final Deque<Vec3> trail = new ArrayDeque<>();
        private final Set<LivingEntity> hit = new HashSet<>();
        private final int maxTicks;
        private final double phase;
        private Vec3 base;
        private Vec3 heading;
        private int t = 0;

        Snake(ServerPlayer owner, ServerLevel lv, SkillDef d, float dmg, Vec3 start, Vec3 heading, int index) {
            this.owner = owner;
            this.lv = lv;
            this.d = d;
            this.dmg = dmg;
            this.base = start;
            this.heading = heading;
            this.maxTicks = Math.max(8, (int) (d.range() / SPEED));
            this.phase = index * 1.7;
        }

        @Override
        public boolean tick() {
            if (owner.isRemoved() || t >= maxTicks) {
                return true;
            }

            // Tự đuổi mục tiêu gần nhất ở phía trước
            LivingEntity target = nearestAhead();
            if (target != null) {
                Vec3 to = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0).subtract(base);
                if (to.lengthSqr() > 0.01) {
                    double homing = d.extra() == Extra.POISON ? 0.35 : 0.2;
                    heading = heading.scale(1.0 - homing).add(to.normalize().scale(homing)).normalize();
                }
            }
            base = base.add(heading.scale(SPEED));

            // Uốn lượn theo đường sin vuông góc với hướng bò
            Vec3 side = new Vec3(-heading.z, 0.0, heading.x);
            double wave = Math.sin(t * 0.8 + phase) * 0.85;
            Vec3 head = base.add(side.scale(wave)).add(0.0, Math.sin(t * 0.5 + phase) * 0.2, 0.0);

            trail.addFirst(head);
            while (trail.size() > BODY_SEGMENTS) {
                trail.removeLast();
            }

            // Thân: nhiều đốt nhỏ dần về phía đuôi, xen kẽ hai màu để thành hoa văn
            int i = 0;
            for (Vec3 seg : trail) {
                float size = (float) Math.max(0.6, 1.5 - i * 0.06);
                Fx.dust(lv, seg, (i % 4 < 2) ? d.color() : d.color2(), size);
                i++;
            }

            // Đầu, mắt đỏ, lưỡi thè
            Fx.dust(lv, head.add(0.0, 0.05, 0.0), d.color(), 2.0f);
            Fx.dust(lv, head.add(side.scale(0.15)).add(0.0, 0.18, 0.0), 0xFF2020, 0.6f);
            Fx.dust(lv, head.subtract(side.scale(0.15)).add(0.0, 0.18, 0.0), 0xFF2020, 0.6f);
            if (t % 6 < 2) {
                Fx.dust(lv, head.add(heading.scale(0.5)), 0xFF5577, 0.4f);
            }
            if (t % 4 == 0) {
                Fx.accent(lv, d.accent(), head, 2, 0.12);
            }

            // Cắn mục tiêu mỗi lần một con
            List<LivingEntity> fresh = new ArrayList<>();
            for (LivingEntity e : SkillExecutor.near(lv, owner, head, 1.5)) {
                if (hit.add(e)) {
                    fresh.add(e);
                }
            }
            if (!fresh.isEmpty()) {
                SkillExecutor.strike(owner, lv, d, dmg, fresh, heading, 0.3);
                Fx.sound(lv, head, "entity.phantom.swoop", 0.6f, 1.6f);
            }

            t++;
            return false;
        }

        private LivingEntity nearestAhead() {
            LivingEntity best = null;
            double bestDist = Double.MAX_VALUE;
            for (LivingEntity e : SkillExecutor.near(lv, owner, base, 8.0)) {
                if (hit.contains(e)) {
                    continue;
                }
                Vec3 to = e.position().subtract(base);
                if (to.lengthSqr() < 0.01 || to.normalize().dot(heading) < 0.3) {
                    continue;
                }
                double dist = to.lengthSqr();
                if (dist < bestDist) {
                    bestDist = dist;
                    best = e;
                }
            }
            return best;
        }
    }
}
