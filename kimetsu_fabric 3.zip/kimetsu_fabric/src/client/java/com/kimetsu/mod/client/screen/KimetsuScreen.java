package com.kimetsu.mod.client.screen;

import com.kimetsu.mod.data.ModAttachments;
import com.kimetsu.mod.data.PlayerState;
import com.kimetsu.mod.item.Costumes;
import com.kimetsu.mod.network.ModNetwork;
import com.kimetsu.mod.skill.SkillDef;
import com.kimetsu.mod.skill.SkillStyle;
import com.kimetsu.mod.skill.Skills;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Menu mở bằng phím K, gồm hai tab:
 *  - Kỹ năng: xem các thức của Hơi Thở (hoặc Huyết Quỷ Thuật), cấp mở khóa, sát thương,
 *    năng lượng, hồi chiêu; đổi Hơi Thở bằng nút mũi tên.
 *  - Trang phục: chọn trang phục để mặc ngay (máy chủ trao và mặc vào đúng ô giáp).
 */
public class KimetsuScreen extends Screen {
    private static final int OPAQUE = 0xFF000000;
    private int tab = 0;

    public KimetsuScreen() {
        super(Component.translatable("screen.kimetsu.title"));
    }

    private PlayerState state() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return PlayerState.DEFAULT;
        }
        return mc.player.getAttachedOrElse(ModAttachments.STATE, PlayerState.DEFAULT);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = this.height / 2 - 105;

        this.addRenderableWidget(Button.builder(Component.translatable("screen.kimetsu.tab_skills"),
                b -> {
                    tab = 0;
                    this.rebuildWidgets();
                }).bounds(cx - 150, top, 148, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("screen.kimetsu.tab_costumes"),
                b -> {
                    tab = 1;
                    this.rebuildWidgets();
                }).bounds(cx + 2, top, 148, 20).build());

        if (tab == 0) {
            if (!state().demon()) {
                this.addRenderableWidget(Button.builder(Component.literal("<"),
                        b -> ClientPlayNetworking.send(new ModNetwork.CycleStyle(-1)))
                        .bounds(cx - 150, top + 26, 20, 20).build());
                this.addRenderableWidget(Button.builder(Component.literal(">"),
                        b -> ClientPlayNetworking.send(new ModNetwork.CycleStyle(1)))
                        .bounds(cx + 130, top + 26, 20, 20).build());
            }
        } else {
            for (int i = 0; i < Costumes.ALL.size(); i++) {
                Costumes.Costume c = Costumes.ALL.get(i);
                int bx = cx - 150 + (i % 2) * 152;
                int by = top + 30 + (i / 2) * 22;
                this.addRenderableWidget(Button.builder(
                        Component.translatable("item.kimetsu." + c.id()),
                        b -> ClientPlayNetworking.send(new ModNetwork.EquipCostume(c.id())))
                        .bounds(bx, by, 148, 20).build());
            }
        }
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        int cx = this.width / 2;
        int top = this.height / 2 - 105;
        g.fill(cx - 158, top - 8, cx + 158, top + 214, 0xFF1B0F14);
        g.fill(cx - 156, top - 6, cx + 156, top + 212, 0xFF120A0E);
        g.fill(cx - 156, top - 6, cx + 156, top - 4, 0xFFB0001A);
        g.fill(cx - 156, top + 210, cx + 156, top + 212, 0xFFB0001A);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        PlayerState s = state();
        int cx = this.width / 2;
        int top = this.height / 2 - 105;

        if (tab == 0) {
            SkillStyle style = s.demon() ? Skills.art(s.school()) : Skills.breathing(s.style());
            int color = style.color() | OPAQUE;
            String head = Component.translatable(style.nameKey()).getString();
            g.drawString(this.font, head, cx - this.font.width(head) / 2, top + 32, color);

            String info = Component.translatable("hud.kimetsu.level").getString() + " " + s.level()
                    + "   XP " + (s.xp() % PlayerState.XP_PER_LEVEL) + "/" + PlayerState.XP_PER_LEVEL
                    + "   " + Component.translatable("hud.kimetsu.energy").getString()
                    + " " + (int) s.maxEnergy();
            g.drawString(this.font, info, cx - this.font.width(info) / 2, top + 46, 0xFFCCCCCC);

            if (s.demon()) {
                String hint = Component.translatable("screen.kimetsu.demon_hint").getString();
                g.drawString(this.font, hint, cx - this.font.width(hint) / 2, top + 58, 0xFFB0001A);
            }

            for (int i = 0; i < style.skills().size(); i++) {
                SkillDef d = style.skills().get(i);
                boolean locked = s.level() < d.minLevel();
                int y = top + 74 + i * 26;
                int nameColor = locked ? 0xFF777777 : (d.color() | OPAQUE);
                String name = (i + 1) + ". " + Component.translatable(d.nameKey()).getString();
                g.drawString(this.font, name, cx - 148, y, nameColor);
                String stats = locked
                        ? Component.translatable("msg.kimetsu.locked", d.minLevel()).getString()
                        : Component.translatable("screen.kimetsu.stats",
                                String.format("%.0f", d.damage() * (1f + 0.03f * (s.level() - 1))),
                                String.format("%.0f", d.cost()),
                                String.format("%.1f", d.cooldown() / 20.0)).getString();
                g.drawString(this.font, stats, cx - 148, y + 11, locked ? 0xFF555555 : 0xFFBBBBBB);
            }
        } else {
            String sel = s.costume().isEmpty()
                    ? Component.translatable("screen.kimetsu.none").getString()
                    : Component.translatable("item.kimetsu." + s.costume()).getString();
            String line = Component.translatable("screen.kimetsu.selected").getString() + " " + sel;
            g.drawString(this.font, line, cx - 148, top + 196, 0xFFCCCCCC);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
