package com.kimetsu.mod.client;

import com.kimetsu.mod.KimetsuMod;
import com.kimetsu.mod.client.hud.SkillHud;
import net.fabricmc.api.ClientModInitializer;

/** Điểm vào phía client: phím tắt, HUD năng lượng/hồi chiêu, menu. */
public class KimetsuClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KeyBinds.register();
        SkillHud.register();
        KimetsuMod.LOGGER.info("Kimetsu mod da khoi dong (client)");
    }
}
