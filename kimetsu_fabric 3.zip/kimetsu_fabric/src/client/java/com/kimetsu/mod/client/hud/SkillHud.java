package com.kimetsu.mod.client.hud;

import com.kimetsu.mod.KimetsuMod;
import com.kimetsu.mod.client.KeyBinds;
import com.kimetsu.mod.data.ModAttachments;
import com.kimetsu.mod.data.PlayerState;
import com.kimetsu.mod.skill.SkillDef;
import com.kimetsu.mod.skill.SkillStyle;
import com.kimetsu.mod.skill.Skills;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * HUD: thanh năng lượng, cấp độ, 5 ô kỹ năng với phím tắt, khóa theo cấp và
 * lớp phủ đếm ngược hồi chiêu. Dữ liệu lấy từ attachment được máy chủ đồng bộ.
 */
public final class SkillHud {
    private static final Identifier ID = Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "skill_hud");
    private static final int OPAQUE = 0xFF000000;

    private SkillHud() {
    }

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, ID, SkillHud::render);
    }

    private static void render(GuiGraphics g, DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.options.hideGui) {
            return;
        }
        PlayerState s = player.getAttachedOrElse(ModAttachments.STATE, PlayerState.DEFAULT);
        SkillStyle style = s.demon() ? Skills.art(s.school()) : Skills.breathing(s.style());
        long now = mc.level.getGameTime();

        int x = 8;
        int y = mc.getWindow().getGuiScaledHeight() - 86;
        int color = style.color() | OPAQUE;

        // Tiêu đề: tên Hơi Thở / Huyết Quỷ Thuật + cấp độ
        String title = Component.translatable(style.nameKey()).getString()
                + "  " + Component.translatable("hud.kimetsu.level").getString() + " " + s.level();
        g.drawString(mc.font, title, x, y, color);

        // Thanh năng lượng
        float max = s.maxEnergy();
        float en = Math.min(max, s.energyAt(now));
        int barW = 130;
        int by = y + 12;
        g.fill(x - 1, by - 1, x + barW + 1, by + 9, OPAQUE);
        g.fill(x, by, x + barW, by + 8, 0xFF2A2A33);
        g.fill(x, by, x + (int) (barW * (en / max)), by + 8, color);
        g.drawString(mc.font, (int) en + "/" + (int) max, x + 3, by, 0xFFFFFFFF);

        // 5 ô kỹ năng
        for (int i = 0; i < style.skills().size(); i++) {
            SkillDef d = style.skills().get(i);
            int bx = x + i * 28;
            int sy = by + 14;
            boolean locked = s.level() < d.minLevel();
            long remain = Math.max(0L, s.readyAt(d.id()) - now);
            boolean noEnergy = en < d.cost();

            int border = locked ? 0xFF555555 : (noEnergy ? 0xFFAA3333 : color);
            g.fill(bx, sy, bx + 26, sy + 26, border);
            g.fill(bx + 1, sy + 1, bx + 25, sy + 25, locked ? 0xFF1A1A1A : 0xFF14141C);

            if (remain > 0L && d.cooldown() > 0) {
                int h = (int) (24L * remain / d.cooldown());
                g.fill(bx + 1, sy + 1, bx + 25, sy + 1 + Math.min(24, h), 0xCC000000);
                g.drawString(mc.font, String.format("%.1f", remain / 20.0), bx + 3, sy + 9, 0xFFFFFFFF);
            } else if (locked) {
                g.drawString(mc.font, "Lv" + d.minLevel(), bx + 3, sy + 9, 0xFF888888);
            } else {
                g.fill(bx + 1, sy + 22, bx + 25, sy + 25, color);
            }
            String key = KeyBinds.SKILLS[i].getTranslatedKeyMessage().getString();
            g.drawString(mc.font, key, bx + 3, sy + 3, 0xFFFFFFFF);
        }
    }
}
