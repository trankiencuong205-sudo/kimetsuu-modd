package com.kimetsu.mod.client;

import com.kimetsu.mod.KimetsuMod;
import com.kimetsu.mod.client.screen.KimetsuScreen;
import com.kimetsu.mod.network.ModNetwork;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

/**
 * Phím tắt (Fabric Key Mapping): Z X C V B dùng kỹ năng 1-5, G đổi Hơi Thở, K mở menu.
 * Người chơi có thể đổi phím trong Cài đặt > Điều khiển.
 */
public final class KeyBinds {
    public static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(KimetsuMod.MOD_ID, "main"));

    public static final KeyMapping[] SKILLS = new KeyMapping[5];
    public static KeyMapping cycle;
    public static KeyMapping menu;

    private KeyBinds() {
    }

    public static void register() {
        int[] codes = {
                InputConstants.KEY_Z, InputConstants.KEY_X, InputConstants.KEY_C,
                InputConstants.KEY_V, InputConstants.KEY_B
        };
        for (int i = 0; i < SKILLS.length; i++) {
            SKILLS[i] = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                    "key.kimetsu.skill" + (i + 1), InputConstants.Type.KEYSYM, codes[i], CATEGORY));
        }
        cycle = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.kimetsu.cycle", InputConstants.Type.KEYSYM, InputConstants.KEY_G, CATEGORY));
        menu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.kimetsu.menu", InputConstants.Type.KEYSYM, InputConstants.KEY_K, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                return;
            }
            for (int i = 0; i < SKILLS.length; i++) {
                while (SKILLS[i].consumeClick()) {
                    ClientPlayNetworking.send(new ModNetwork.UseSkill(i));
                }
            }
            while (cycle.consumeClick()) {
                ClientPlayNetworking.send(new ModNetwork.CycleStyle(1));
            }
            while (menu.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new KimetsuScreen());
                }
            }
        });
    }
}
