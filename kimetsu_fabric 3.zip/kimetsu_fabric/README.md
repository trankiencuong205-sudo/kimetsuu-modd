# Kimetsu Breathing (Fabric 1.21.11)

Mod lấy cảm hứng từ Kimetsu no Yaiba. **Trạng thái: chưa từng được biên dịch hay chạy thử trong game.**
Bản này viết theo tài liệu Fabric 1.21.11 nhưng chưa có lần build thật nào xác nhận.

## Cách chơi

| Phím | Tác dụng |
|------|----------|
| Z X C V B | Dùng kỹ năng 1 đến 5 |
| G | Đổi Hơi Thở (chỉ khi là người) |
| K | Mở menu: xem kỹ năng và chọn trang phục |

Đổi phím ở Cài đặt > Điều khiển > Kimetsu.

- **Hơi Thở** cần cầm Kiếm Nichirin. 9 Hơi Thở, mỗi Hơi Thở 5 thức, mở khóa theo cấp 1, 3, 6, 9, 12.
- **Năng lượng** hồi theo thời gian, hồi nhanh hơn khi là quỷ. Mỗi thức có tiêu hao, hồi chiêu, sát thương riêng.
- **Cấp độ** tăng khi hạ quái (+12 XP), hạ sinh vật (+4 XP) và dùng kỹ năng (+3 XP). Cấp tối đa 20.
- **Hóa quỷ**: chuột phải Máu Quỷ. Nhận ngẫu nhiên 1 trong 6 trường phái Huyết Quỷ Thuật (3 kỹ năng, mở khóa cấp 1, 5, 10).
  Quỷ khỏe hơn, tự hồi máu, nhìn trong đêm, nhưng **cháy dưới nắng**. Quỷ không cần cầm kiếm.
- **Trở lại làm người**: chuột phải Tinh Chất Tử Đằng.
- **Trang phục**: menu K > tab Trang phục, bấm để mặc vào đúng ô giáp. Món đang mặc được trả về túi đồ.
- Trạng thái (quỷ, cấp, hồi chiêu, trang phục đã chọn) được lưu cùng người chơi, còn nguyên sau khi thoát game.

## Chỉnh số liệu

Mở `src/main/java/com/kimetsu/mod/skill/Skills.java`. Mỗi dòng `d("water_1", ...)` theo thứ tự:
id, hình dạng, sát thương, tầm, năng lượng, hồi chiêu (tick, 20 tick = 1 giây), cấp mở khóa, màu 1, màu 2, hạt, âm thanh, hiệu ứng phụ, thời lượng hiệu ứng, tốc độ lao, số rắn.

## Build

Cần JDK 21. `gradle build` (hoặc `./gradlew build` nếu có wrapper). File mod nằm ở `build/libs/`, dùng file không có hậu tố `-sources`.

## Giới hạn hiện tại

- Hiệu ứng (nhát chém, sóng, rắn...) được vẽ bằng hạt vanilla từ phía máy chủ nên đồng bộ multiplayer, nhưng chưa phải model 3D hay hoạt ảnh riêng.
- Rắn của Hơi Thở Rắn là rắn dựng bằng hạt (đầu, thân nhiều đốt, mắt, lưỡi), tự đuổi mục tiêu, chưa phải entity có model.
- Chưa có quỷ làm mob, boss, NPC, lời thoại và nhiệm vụ.
